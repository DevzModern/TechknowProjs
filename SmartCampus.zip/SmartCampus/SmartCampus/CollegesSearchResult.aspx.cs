﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;

namespace SmartCampus
{
    public partial class CollegesSearchResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindTopCollegesToHTML();
            }
        }

        public void BindTopCollegesToHTML()
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.ClgDetails WHERE IsUniversity='No'", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }

            BindDataToHTMLControl(dt);
        }

        private void BindDataToHTMLControl(DataTable dt)
        {
            StringBuilder html = new StringBuilder();
            if (dt != null && dt.Rows.Count > 0)
            {
                html.Append("<div class=\"row\">");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<div class=\"col-md-4 mb-4\"><div class=\"card h-100\">");
                    html.Append("<div class=\"card-body\"><a href=\"CollegeInfo.aspx?clgId=" + row["ClgId"] + "\"><img class=\"card-img-top\" height=\"120px\" src=\"" + row["Photo"] + "\" alt=\"\"/></a><br /><br /><a href=\"CollegeInfo.aspx?clgId=" + row["ClgId"] + "\" style=\"font-size:smaller\">" + row["Name"] + "</a><br /><label style=\"color:Orange; font-size:medium; margin-left:75%\">1.5L/Yr</label></div>");
                    //html.Append("<div class=\"card-body\"><a href=\"#\"><img class=\"card-img-top\" height=\"120px\" src=\"" + row["Photo"] + "\" alt=\"\"/></a><br /><br /><a href=\"#\" style=\"font-size:smaller\">" + row["Name"] + "</a><br /><label style=\"color:Orange; font-size:medium; margin-left:75%\">1.5L/Yr</label></div>");
                    html.Append("<div class=\"card-footer\"><a href=\"CollegeInfo.aspx?clgId="+ row["ClgId"]+ "\" class=\"btn btn-primary\">More Info</a></div>");
                    html.Append("</div></div>");
                }
                html.Append("</div>");
            }
            else
            {
                html.Append("<div class=\"row\" style=\"text-align:center; margin-left:22%\">");
                html.Append("<h3>No matching college sound!</h3>");
                html.Append("</div>");
            }
            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected void chkStreams_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.vw_ClgStream WHERE IsUniversity='No'" + GetFilterCriteria(), con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            BindDataToHTMLControl(dt);
        }

        protected void chkState_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.vw_ClgStream WHERE IsUniversity='No'" + GetFilterCriteria(), con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            BindDataToHTMLControl(dt);
        }

        private string GetFilterCriteria()
        {
            string whereClause = string.Empty;

            List<string> selectedState = new List<string>();
            List<string> selectedStreams = new List<string>();

            foreach (ListItem lstState in chkState.Items)
            {
                if (lstState.Selected == true)
                    selectedState.Add("'" + lstState.Value + "'");
            }

            foreach (ListItem lstStream in chkStreams.Items)
            {
                if (lstStream.Selected == true)
                    selectedStreams.Add("'" + lstStream.Value + "'");
            }

            if (selectedState.Count > 0)
            {
                whereClause = " AND State IN (" + String.Join(",", selectedState) + ")";
            }

            if (selectedStreams.Count > 0)
            {
                whereClause = whereClause + " AND ShortName IN (" + String.Join(",", selectedStreams) + ")";
            }

            if (string.IsNullOrEmpty(whereClause)) {
                whereClause = " AND 1=1";
            }

            return whereClause;
        }
    }
}