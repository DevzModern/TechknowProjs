﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SmartCampus.UserControls
{
    public partial class ucUniversityFilter : System.Web.UI.UserControl
    {
        public string SelectedStream
        {
            get {
                if (chkStreams != null)
                {
                    return chkStreams.SelectedValue;
                }
                else {
                    return "0";
                }
            }

            set { chkStreams.SelectedValue = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}