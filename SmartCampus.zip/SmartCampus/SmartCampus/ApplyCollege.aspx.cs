﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SmartCampus
{
    public partial class ApplyCollege : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedInMemberId"] == null)
            {
                Session["Login"] = 1;
                Response.Redirect("Login.aspx?ReturnURL=CollegeInfo.aspx?ClgId=" + Request.QueryString["clgId"]);
            }
            else
            {
                ApplyToCollege();
            }
        }

        private void ApplyToCollege()
        {
            Models.MemberDetails obj = new Models.MemberDetails();
            int clgid = Convert.ToInt32(Request.QueryString["clgId"]);
            int memberid = Convert.ToInt32(Session["LoggedInMemberId"]);
            obj.ApplyForClg(clgid, memberid);

            lblMsg.Text = "Your application has been send to college..";
        }
    }
}