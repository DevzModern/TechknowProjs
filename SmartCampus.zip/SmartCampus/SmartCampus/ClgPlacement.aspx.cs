﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace SmartCampus
{
    public partial class ClgPlacement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetClgDetailsById();
            }
        }

        private void GetClgDetailsById()
        {
            DataTable dt = new DataTable();
            int clgid = 0;

            if (Request.QueryString["clgId"] != null)
            {
                clgid = Convert.ToInt32(Request.QueryString["clgId"]);
                Session["ClgId"] = Convert.ToInt32(Request.QueryString["clgId"]);
            }
            else
                clgid = Convert.ToInt32(Session["ClgId"]);

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.ClgDetails WHERE ClgId=" + clgid, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    imgClgPhtot.ImageUrl = (string)dt.Rows[0]["Photo"];
                    lblClgName.Text = (string)dt.Rows[0]["Name"];
                    lblStateCity.Text = " " + (string)dt.Rows[0]["City"] + ", " + (string)dt.Rows[0]["State"];
                    lblESTD.Text = "ESTD " + (string)dt.Rows[0]["ESTDYear"];
                    lblType.Text = (string)dt.Rows[0]["Type"];
                }
            }

            BindCompanyImages(clgid);
        }

        private void BindCompanyImages(int clgid)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT Distinct ImgPath From dbo.ClgPlacement WHERE Clg_Id=" + clgid, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    StringBuilder html = new StringBuilder();
                    foreach (DataRow row in dt.Rows)
                    {
                        foreach (DataColumn column in dt.Columns)
                        {
                            html.Append("<div class=\"col-md-4 mb-4\"><div class=\"card h-100\"><div class=\"card-body\"><img class=\"card-img-top\" src=\"" + row["ImgPath"] + "\" alt=\"\" height=\"220px\"/></div></div></div>");
                        }
                    }
                    imagesPlaceHolder.Controls.Add(new Literal { Text = html.ToString() });
                }
            }
        }
    }
}