﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace SmartCampus
{
    public partial class CoursesByType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetClgDetailsById();
            }
        }

        private void GetClgDetailsById()
        {
            DataTable dt = new DataTable();

            int streamid = Convert.ToInt32( Request.QueryString["StreamId"]);

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("select Expr1 as [Course Name], COUNT(ClgId) AS [No OF Colleges] From dbo.vw_ClgSubStream WHERE Stream_Id =  " + streamid +  " Group by Expr1" , con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    //imgClgPhtot.ImageUrl = (string)dt.Rows[0]["Photo"];
                    //lblClgName.Text = (string)dt.Rows[0]["Name"];
                    //lblStateCity.Text = " " + (string)dt.Rows[0]["City"] + ", " + (string)dt.Rows[0]["State"];
                    //lblESTD.Text = "ESTD " + (string)dt.Rows[0]["ESTDYear"];
                    ////lblUniv.Text = (string)dt.Rows[0]["UniversityType"];
                    //lblType.Text = (string)dt.Rows[0]["Type"];
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    StringBuilder html = new StringBuilder();
                    foreach (DataRow row in dt.Rows)
                    {
                        html.Append("<div class=\"col-md-12 mb-4\"><div class=\"card h-100\"><div class=\"card-body\"><h5 class=\"card-title\">" + row["Course Name"] + "</h5><br /><h7>COLLEGES OFFERING THIS COURSE:</h7><p class=\"card-text\"><a href=\"CollegesSearchResult.aspx\" style=\"font-size:40px; font-weight:bold; color:#ff7979;cursor: default;\">" + row["No OF Colleges"] + "</a></p></div>");


                        html.Append("</div></div>");
                    }
                    reviewsPlaceHolder.Controls.Add(new Literal { Text = html.ToString() });
                }
            }
        }
    }
}