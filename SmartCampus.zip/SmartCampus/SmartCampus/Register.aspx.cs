﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using SmartCampus.Models;

namespace SmartCampus
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.MemberDetails objMemberDetails = new Models.MemberDetails();
            objMemberDetails.MemberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            if (CheckIfUserExist(txtEmail.Text))    // Check if email id already exist
            {
                //user exist so dont save
                Lblstatusmessage.Text = "this email id already exits ";
            }
            else { 
                //Below code will insert new user into MemberDetails table
                Random otp = new Random();
                String OTPNumber = otp.Next(0, 9999).ToString();

                int cid = objMemberDetails.InsertNewMemberDetails(txtEmail.Text, txtPwd.Text, txtName.Text, txtMobile.Text, txtDOB.Text, OTPNumber, "False");
                SendEmail();
                Lblstatusmessage.Text = "You've successfully registered!";
                hotpLink.Visible = true;
                Session["CidToConfirmOTP"] = cid;

                MailUtility.SendMail(txtEmail.Text, "Successfully registered", "Successfully registered Your OTP:" + OTPNumber);
            }           
           
        }

        private void SendEmail() { 
        
        }

        private Boolean CheckIfUserExist(string emailId)
        {
            Boolean _isUserExist = false;

            //

            DataTable dt = new DataTable();
           // string searchText = Request.QueryString["SearchText"];
            string filterClause = string.Empty;

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.MemberDetails WHERE Email='" + emailId + "'", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        _isUserExist = true;
                    }
                }

                return _isUserExist;
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        public string isEmailId { get; set; }
    }
}