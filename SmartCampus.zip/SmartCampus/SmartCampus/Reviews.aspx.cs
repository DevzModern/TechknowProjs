﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace SmartCampus
{
    public partial class Reviews : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetClgDetailsById();
            }
        }

        private void GetClgDetailsById()
        {
            DataTable dt = new DataTable();

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.vw_ClgReview", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    //imgClgPhtot.ImageUrl = (string)dt.Rows[0]["Photo"];
                    //lblClgName.Text = (string)dt.Rows[0]["Name"];
                    //lblStateCity.Text = " " + (string)dt.Rows[0]["City"] + ", " + (string)dt.Rows[0]["State"];
                    //lblESTD.Text = "ESTD " + (string)dt.Rows[0]["ESTDYear"];
                    ////lblUniv.Text = (string)dt.Rows[0]["UniversityType"];
                    //lblType.Text = (string)dt.Rows[0]["Type"];
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    StringBuilder html = new StringBuilder();
                    foreach (DataRow row in dt.Rows)
                    {
                        html.Append("<div class=\"col-md-12 mb-4\"><div class=\"card h-100\"><div class=\"card-body\"><h5 class=\"card-title\">" + row["Title"] + "</h5><p class=\"card-text\">" + row["Comments"] + "</p></div>");

                        html.Append("<div class=\"card-footer\"><table style=\"width: 100%\"><tr>");

                        html.Append("<td style=\"width: 15%\"><label style=\"font-size: large; font-weight: bold; color: #3eae8d;\">" + row["Academic_Rating"] + "</label><br />ACADEMICS</td>");

                        html.Append("<td style=\"width: 15%\"><label style=\"font-size: large; font-weight: bold; color: #ffa100;\">" + row["Accomodation_Rating"] + "</label><br />ACCOMODATION</td>");

                        html.Append("<td style=\"width: 15%\"><label style=\"font-size: large; font-weight: bold; color: #ff7979;\">" + row["Faculty__Rating"] + "</label><br />FACULTY</td>");

                        html.Append("<td style=\"width: 15%\"><label style=\"font-size: large; font-weight: bold; color: #3eae8d;\">" + row["Infra_Rating"] + "</label><br />INFRASRTUCTURE</td>");

                        html.Append("<td style=\"width: 15%\"><label style=\"font-size: large; font-weight: bold; color: #ffa100;\">" + row["Placement_Rating"] + "</label><br />PLACEMENT</td>");

                        html.Append("</tr></table></div></div></div>");
                    }
                    reviewsPlaceHolder.Controls.Add(new Literal { Text = html.ToString() });
                }
            }
        }
    }
}