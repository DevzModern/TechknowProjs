﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SmartCampus
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedInMemberId"] != null)
                Response.Redirect("Member/Dashboard.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (ValidateUser())
            {
                var returnUrl = Request.QueryString["ReturnURL"];
                if (string.IsNullOrEmpty(returnUrl))
                {
                    Response.Redirect("Member/Dashboard.aspx");
                }
                else
                {
                    Response.Redirect("~/" + returnUrl);
                }
            }
            else
            {
                lblLoginStatus.Text = "Invalid email or password OR Account not activated!";
                lblLoginStatus.ForeColor = System.Drawing.Color.Red;
            }
        }

        public Boolean ValidateUser()
        {
            Boolean isValid = false;

            DataTable dt = new DataTable();
            string userName = txtEmail.Text;
            string pwd = txtPwd.Text;

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.MemberDetails WHERE Email='" + userName + "' AND Password='" + pwd + "'", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        Session["LoggedInMemberId"] = dt.Rows[0]["MemberId"];

                        Session["LoggedInName"] = dt.Rows[0]["Name"];
                        Session["LoggedInEmail"] = dt.Rows[0]["Email"];
                        Session["LoggedInProfile"] = dt.Rows[0]["ProfilePhto"];
                        isValid = true;

                        if (Convert.ToString(dt.Rows[0]["IsActive"]).Equals("False"))
                        {
                            isValid = false;
                        }
                    }

                }
            }
            return isValid;
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}