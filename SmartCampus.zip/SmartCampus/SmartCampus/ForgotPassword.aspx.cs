﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SmartCampus.Models;

namespace SmartCampus
{
    public partial class ForgotPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.MemberDetails md = new Models.MemberDetails();
            DataTable dt = md.GetPassword(txtEmail.Text);
            if (dt != null && dt.Rows.Count > 0)
            {
                string pwd = (string)dt.Rows[0]["Password"];
                lblLoginStatus.Text = "Profile password is sent on your registered email id.";

                MailUtility.SendMail(txtEmail.Text, "Profile Password", "Your profile password :" + pwd);
            }
        }
    }
}