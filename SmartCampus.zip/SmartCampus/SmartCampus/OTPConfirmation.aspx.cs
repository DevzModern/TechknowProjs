﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SmartCampus
{
    public partial class OTPConfirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int cid = Convert.ToInt32(Session["CidToConfirmOTP"]);
            Models.MemberDetails md = new Models.MemberDetails();
            DataTable dt = md.GetOTP(cid);
            if (dt != null && dt.Rows.Count > 0)
            {
                if (txtOTP.Text == (string)dt.Rows[0]["OTP"])
                {
                    ActivateAccount();
                }
                else
                {
                    lblLoginStatus.Text = "Wrong OTP, Please enter valid OTP.";
                }
            }
        }

        private void ActivateAccount()
        {
            int cid = Convert.ToInt32(Session["CidToConfirmOTP"]);
            Models.MemberDetails md = new Models.MemberDetails();
            md.ActivateAccount(cid);

            lblLoginStatus.Text = "Account Activated..";
        }
    }
}