﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace SmartCampus
{
    public partial class WriteReview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedInMemberId"] == null)
            {
                //string str2 = "<script language='javascript'>alert('Are you not logged in. First you log in.'); return false;</script>";
                //ClientScript.RegisterStartupScript(GetType(), "PopUp", str2);

                Session["Login"] = 1;
                Response.Redirect("Login.aspx?ReturnURL=WriteReview.aspx");
            }
        }

        protected void ddlReviewFor_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlCollege.Items.Clear();
            ddlCollege.Items.Add(new ListItem("-1", "--Select--"));

            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT ClgId,Name From dbo.ClgDetails WHERE IsUniversity='" + ddlReviewFor.SelectedItem.Value + "'", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                ddlCollege.DataTextField = "Name";
                ddlCollege.DataValueField = "ClgId";
                ddlCollege.DataSource = dt;
                ddlCollege.DataBind();
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.CollegeReviewDetails objCollegeReviewDetails = new Models.CollegeReviewDetails();
            int _memberid = Convert.ToInt32(Session["LoggedInMemberId"]);

            int reviewId = objCollegeReviewDetails.InsertNewMemberDetails(txtTitle.Text, txtComments.Text,
                Convert.ToDecimal(ddlAcademics.SelectedValue), Convert.ToDecimal(ddlAcco.SelectedValue), Convert.ToDecimal(ddlFac.SelectedValue),
                Convert.ToDecimal(ddlInfra.SelectedValue), Convert.ToDecimal(ddlplace.SelectedValue));

            objCollegeReviewDetails.InsertClgReviewMapping(Convert.ToInt32(ddlCollege.SelectedItem.Value), reviewId, _memberid);
            lblmsg.Text = "Your review has been submitted!";
        }

    }
}