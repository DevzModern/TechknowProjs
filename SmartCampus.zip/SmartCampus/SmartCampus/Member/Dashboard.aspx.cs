﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace SmartCampus.Member
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["LoggedInMemberId"] != null)
                {
                    int memberId = Convert.ToInt32(Session["LoggedInMemberId"]);
                    BindMemberDetails(memberId);
                }
                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        private void BindMemberDetails(int memberID)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.MemberDetails WHERE MemberId=" + memberID, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    txtPassYr.Text = (dt.Rows[0]["PassingYear"] == DBNull.Value)? "" : (string)dt.Rows[0]["PassingYear"];
                    txtCity.Text = (dt.Rows[0]["City"] == DBNull.Value) ? "" : (string)dt.Rows[0]["City"];
                    txtAddress.Text = (dt.Rows[0]["Address"] == DBNull.Value) ? "" : (string)dt.Rows[0]["Address"];
                    txtPin.Text = (dt.Rows[0]["PinCode"] == DBNull.Value) ? "" : (string)dt.Rows[0]["PinCode"];
                    txtAboutMe.Text = (dt.Rows[0]["AboutMe"] == DBNull.Value) ? "" : (string)dt.Rows[0]["AboutMe"];
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.MemberDetails objMemberDetails = new Models.MemberDetails();
            objMemberDetails.MemberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            objMemberDetails.UpdateMemberDetails(txtPassYr.Text, txtCity.Text, txtAddress.Text, txtPin.Text, txtAboutMe.Text);
        }
    }
}