﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SmartCampus.Member
{
    public partial class ChangeProfileImage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            Models.MemberDetails objMemberDetails = new Models.MemberDetails();
            objMemberDetails.MemberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            if (Fupload.HasFile)
            {
                Fupload.SaveAs(MapPath("~/img/members/") + Fupload.PostedFile.FileName);
                objMemberDetails.ProfileImg = "../img/members/" + Fupload.PostedFile.FileName;

                objMemberDetails.UpdateProfileImg();
                Image profImgControl = (Image)Master.FindControl("imgProfile");
                profImgControl.ImageUrl = objMemberDetails.ProfileImg;

                lblError.Text = "Profile image updated..";
                lblError.ForeColor = System.Drawing.Color.Green;
            }
            else {
                lblError.Text = "Please select profile image to update..";
                lblError.ForeColor = System.Drawing.Color.Red;
            }
        }

    }
}