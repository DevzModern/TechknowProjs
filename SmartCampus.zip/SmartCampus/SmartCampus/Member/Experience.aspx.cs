﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SmartCampus.Member
{
    public partial class Experience : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["LoggedInMemberId"] != null)
                {
                    int memberId = Convert.ToInt32(Session["LoggedInMemberId"]);
                    BindExperienceDetails(memberId);
                }
                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        private void BindExperienceDetails(int memberID)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.MemberExpDetails WHERE Member_Id=" + memberID, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    ddlCompany.SelectedValue = (string)dt.Rows[0]["Company"];
                    ddlExpiYr.SelectedValue = (string)dt.Rows[0]["ExpYears"];
                    txtSpecialization.Text = (string)dt.Rows[0]["Specialization"];
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.MemberDetails objMemberDetails = new Models.MemberDetails();
            objMemberDetails.MemberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            objMemberDetails.UpdateMemberExpDetails(ddlCompany.SelectedValue, ddlExpiYr.SelectedValue, txtSpecialization.Text);
        }
    }
}