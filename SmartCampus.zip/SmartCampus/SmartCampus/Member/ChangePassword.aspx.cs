﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SmartCampus.Member
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.MemberDetails objMemberDetails = new Models.MemberDetails();
            int memberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            //TODO: Check if old password is valid
            objMemberDetails.UpdateProfilePassword(memberId, txtnew.Text);
        }
    }
}