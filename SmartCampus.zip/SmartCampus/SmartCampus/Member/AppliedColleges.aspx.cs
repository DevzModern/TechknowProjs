﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;

namespace SmartCampus.Member
{
    public partial class AppliedColleges : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindTopCollegesToHTML();
            }
        }

        public void BindTopCollegesToHTML()
        {
            int memberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.vw_AppliedColleges WHERE Member_Id='" + memberId + "'", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }

            BindDataToHTMLControl(dt);
        }

        private void BindDataToHTMLControl(DataTable dt)
        {
            StringBuilder html = new StringBuilder();
            if (dt != null && dt.Rows.Count > 0)
            {
                html.Append("<div class=\"row\">");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<div class=\"col-md-4 mb-4\"><div class=\"card h-100\">");
                    html.Append("<div class=\"card-body\"><a href=\"#\"><img class=\"card-img-top\" height=\"120px\" src=\"../" + row["Photo"] + "\" alt=\"\"/></a><br /><br /><a href=\"#\" style=\"font-size:smaller\">" + row["Name"] + "</a><br /><label style=\"color:Orange; font-size:medium; margin-left:75%\">1.5L/Yr</label></div>");
                    html.Append("<div class=\"card-footer\"><a href=\"../CollegeInfo.aspx?clgId=" + row["ClgId"] + "\" class=\"btn btn-primary\">More Info</a></div>");
                    html.Append("</div></div>");
                }
                html.Append("</div>");
            }
            else
            {
                html.Append("<div class=\"row\" style=\"text-align:center; margin-left:22%\">");
                html.Append("<h3>No data sound!</h3>");
                html.Append("</div>");
            }

            PlaceHolder1.Controls.Add(new Literal { Text = html.ToString() });
        }
    }
}