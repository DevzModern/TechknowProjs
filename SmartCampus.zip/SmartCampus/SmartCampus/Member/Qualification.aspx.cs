﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace SmartCampus.Member
{
    public partial class Qualification : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["LoggedInMemberId"] != null)
                {
                    int memberId = Convert.ToInt32(Session["LoggedInMemberId"]);
                    BindQualificationDetails(memberId);
                }
                else
                {
                    Response.Redirect("../Login.aspx");
                }
            }
        }

        private void BindQualificationDetails(int memberID)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.MemberQualDetails WHERE Member_Id=" + memberID, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    txtSSCPassYr.Text = (string)dt.Rows[0]["SSCPassYear"];
                    txtSSCMarks.Text = (string)dt.Rows[0]["SSCMarks"];
                    txtHSCPassYr.Text = (string)dt.Rows[0]["HSCPassYear"];
                    txtHSCMarks.Text = (string)dt.Rows[0]["HSCMarks"];
                    txtGradYr.Text = (string)dt.Rows[0]["GradPAssYear"];
                    txtGradMarks.Text = (string)dt.Rows[0]["GradMarks"];
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Models.MemberDetails objMemberDetails = new Models.MemberDetails();
            objMemberDetails.MemberId = Convert.ToInt32(Session["LoggedInMemberId"]);

            objMemberDetails.UpdateMemberQualDetails(txtSSCPassYr.Text, txtSSCMarks.Text, txtHSCPassYr.Text, txtHSCMarks.Text, txtGradYr.Text, txtGradMarks.Text);
        }
    }
}