﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SmartCampus.Member
{
    public partial class MemberMain : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblName.Text = (string)Session["LoggedInName"];
            lblEmail.Text = (string)Session["LoggedInEmail"];

            BindProfileImage();
        }

        private void BindProfileImage()
        {
            DataTable dt = new DataTable();
            int memberid = Convert.ToInt32(Session["LoggedInMemberId"]);
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.MemberDetails WHERE MemberId='" + memberid + "'", con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        imgProfile.ImageUrl = (string)dt.Rows[0]["ProfilePhto"];
                    }
                }
            }
        }
    }
}