﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace SmartCampus.Models
{
    public class MemberDetails
    {
        public int MemberId { get; set; }
        public string ProfileImg { get; set; }

        public int UpdateProfileImg()
        {
            string[] paramName = { "@MemberId", "@ProfileImg" };
            object[] paramValue = { MemberId, ProfileImg };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateProfileImg");
            }
            catch
            {
                return 0;
            }
        }

        public int UpdateMemberExpDetails(string comp, string expyr, string spec)
        {
            string[] paramName = { "@MemberId", "@Company", "@ExpYears", "@Specialization" };
            object[] paramValue = { MemberId, comp, expyr, spec };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateMemberExpDetails");
            }
            catch
            {
                return 0;
            }
        }

        public int UpdateMemberQualDetails(string sscyr, string sscmarks, string hscyr, string hscmarks, string gradyr, string gradmarks)
        {
            string[] paramName = { "@MemberId", "@SSCPassYear", "@SSCMarks", "@HSCPassYear", "@HSCMarks", "@GradPAssYear", "@GradMarks" };
            object[] paramValue = { MemberId, sscyr, sscmarks, hscyr, hscmarks, gradyr, gradmarks };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateMemberQualDetails");
            }
            catch
            {
                return 0;
            }
        }

        public int UpdateMemberDetails(string passyr, string city, string add, string pin, string me)
        {
            string[] paramName = { "@MemberId", "@PassingYear", "@City", "@Address", "@PinCode", "@AboutMe" };
            object[] paramValue = { MemberId, passyr, city, add, pin, me };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateMemberDetails");
            }
            catch
            {
                return 0;
            }
        }

        public int InsertNewMemberDetails(string email, string pwd, string name, string mobile, string dob, string otp, string isActive)
        {
            string[] paramName = { "@Email", "@Password", "@Name", "@MobileNo", "@DOB", "@OTP" };
            object[] paramValue = { email, pwd, name, mobile, dob, otp };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_InsertNewMemberDetails", true);
            }
            catch
            {
                return 0;
            }
        }

        public int ApplyForClg(int clgid, int memberid)
        {
            string[] paramName = { "@Clg_Id", "@Member_Id" };
            object[] paramValue = { clgid, memberid };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_ApplyForClg");
            }
            catch
            {
                return 0;
            }
        }

        public int UpdateProfilePassword(int cid, string pwd)
        {
            string[] paramName = { "@Cid", "@Password" };
            object[] paramValue = { cid, pwd };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_UpdateProfilePassword");
            }
            catch
            {
                return 0;
            }
        }

        public DataTable GetOTP(int cid)
        {
            string[] paramName = { "@Cid" };
            object[] paramValue = { cid };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetOTP");
            }
            catch
            {
                return null;
            }
        }

        public int ActivateAccount(int cid)
        {
            string[] paramName = { "@Cid"};
            object[] paramValue = { cid};
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_ActivateAccount");
            }
            catch
            {
                return 0;
            }
        }

        public DataTable GetPassword(string email)
        {
            string[] paramName = { "@Email" };
            object[] paramValue = { email };
            try
            {
                return DataAccess.GetData(paramName, paramValue, "usp_GetPassword");
            }
            catch
            {
                return null;
            }
        }
    }
}