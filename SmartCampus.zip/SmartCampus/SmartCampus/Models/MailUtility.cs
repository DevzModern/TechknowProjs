﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;
using System.Net;

namespace SmartCampus.Models
{
    public class MailUtility
    {
        public static int SendMail(string receipientEmailID, string mailSubject, string mailBody)
        {
            string smtpAddress = "smtp.gmail.com";
            int portNumber = 587;
            bool enableSSL = true;

            //Give Secured Access to this mail id https://support.google.com/accounts/answer/6010255?hl=en
            string emailFrom = "busdemand123@gmail.com";
            string password = "bus12345";

            string emailTo = receipientEmailID;
            string subject = mailSubject;
            string body = mailBody;

            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress(emailFrom);
                mail.To.Add(emailTo);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;
                // Can set to false, if you are sending pure text.

                //using (SmtpClient smtp = new SmtpClient(smtpAddress, portNumber)
                //{ }
                SmtpClient smtp = new SmtpClient(smtpAddress, portNumber);
                smtp.Credentials = new NetworkCredential(emailFrom, password);
                smtp.EnableSsl = enableSSL;
                smtp.Send(mail);
            }
            return 0;
        }
    }
}