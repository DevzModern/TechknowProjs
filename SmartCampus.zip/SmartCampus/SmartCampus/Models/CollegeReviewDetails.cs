﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartCampus.Models
{
    public class CollegeReviewDetails
    {
        public int InsertNewMemberDetails(string title, string comments, decimal academics, decimal acco, decimal fac, decimal infra, decimal place)
        {
            string[] paramName = { "@Title", "@Comments", "@Academic_Rating", "@Accomodation_Rating", "@Faculty__Rating", "@Infra_Rating", "@Placement_Rating", "@Social_Rating" };
            object[] paramValue = { title, comments, academics, acco, fac, infra, place, 0.0 };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_InsertClgReview", true);
            }
            catch
            {
                return 0;
            }
        }

        public int InsertClgReviewMapping(int clgid, int reviewid, int memberid)
        {
            string[] paramName = { "@Clg_Id", "@Review_Id", "@Member_Id" };
            object[] paramValue = { clgid, reviewid, memberid };
            try
            {
                return DataAccess.InsertUpdate(paramName, paramValue, "usp_InsertClgReviewMapping");
            }
            catch
            {
                return 0;
            }
        }
    }
}