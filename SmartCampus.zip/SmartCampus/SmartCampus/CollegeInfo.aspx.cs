﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace SmartCampus
{
    public partial class CollegeInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["ClgId"] != null)
                    if (Request.QueryString["clgId"] != null)
                        if (Convert.ToInt32(Session["ClgId"]) != Convert.ToInt32(Request.QueryString["clgId"]))
                            Session["ClgId"] = Convert.ToInt32(Request.QueryString["clgId"]);

                GetClgDetailsById();
            }
        }

        private void GetClgDetailsById()
        {
            DataTable dt = new DataTable();
            int clgid = 0;

            if (Request.QueryString["clgId"] != null)
            {
                clgid = Convert.ToInt32(Request.QueryString["clgId"]);
                Session["ClgId"] = Convert.ToInt32(Request.QueryString["clgId"]);
            }
            else
                clgid = Convert.ToInt32(Session["ClgId"]);

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.ClgDetails WHERE ClgId=" + clgid, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    imgClgPhtot.ImageUrl = (string)dt.Rows[0]["Photo"];
                    lblClgName.Text = (string)dt.Rows[0]["Name"];
                    lblStateCity.Text = " " + (string)dt.Rows[0]["City"] + ", " + (string)dt.Rows[0]["State"];
                    lblESTD.Text = "ESTD " + (string)dt.Rows[0]["ESTDYear"];
                    //lblUniv.Text = (string)dt.Rows[0]["UniversityType"];
                    if ((string)dt.Rows[0]["IsUniversity"] == "No")
                    {
                        universLink.Text = "UNIVERSITY";
                        universLink.NavigateUrl = "CollegeInfo.aspx?clgId=" + Convert.ToString(dt.Rows[0]["University_Id"]);
                    }
                    lblType.Text = (string)dt.Rows[0]["Type"];
                }
            }

            BindCourseFees(clgid);
            BindSubStreams(clgid);
        }

        private void BindCourseFees(int clgid)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.vw_ClgStream WHERE Clg_Id=" + clgid, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    lblStream.Text = (string)dt.Rows[0]["Expr1"];
                    lblDuration.Text = (string)dt.Rows[0]["Duration"];
                    lblTime.Text = (string)dt.Rows[0]["Time"];
                    lblPlace.Text = (string)dt.Rows[0]["Place"];
                    lblTotalFees.Text = Convert.ToString(dt.Rows[0]["TotalFees"]);
                }
            }
        }

        private void BindSubStreams(int clgid)
        {
            DataTable dt = new DataTable();
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT SubStreamId as [Course Id#], Expr1 as [Stream] From dbo.vw_ClgSubStream WHERE Clg_Id=" + clgid, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    StringBuilder html = new StringBuilder();
                    if (dt.Rows.Count > 0)
                    {
                        html.Append("<table class=\"table table-bordered table-hover\"");
                        html.Append("<thead><tr>");
                        foreach (DataColumn column in dt.Columns)
                        {
                            html.Append("<th>");
                            html.Append(column.ColumnName);
                            html.Append("</th>");
                        }

                        html.Append("<th>");
                        html.Append("Fees Details");
                        html.Append("</th>");

                        html.Append("</tr></thead>");
                        html.Append("<tbody>");
                        foreach (DataRow row in dt.Rows)
                        {
                            html.Append("<tr>");
                            foreach (DataColumn column in dt.Columns)
                            {
                                html.Append("<td>");
                                html.Append(row[column.ColumnName]);
                                html.Append("</td>");
                            }

                            html.Append("<td>");
                            html.Append("<a href=\"CourseFeesInfo.aspx?SubstreamId=" + row["Course Id#"] + "&ClgId=" + clgid + "\">View</a>");
                            html.Append("</td>");

                            html.Append("</tr>");
                        }

                        html.Append("</tbody>");
                        html.Append("</table>");
                    }

                    SubStreamPlaceHolder.Controls.Add(new Literal { Text = html.ToString() });
                }
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            if (Request.QueryString["clgId"] != null)
            {
                Response.Redirect("ApplyCollege.aspx?ClgId=" + Request.QueryString["clgId"]);
            }
        }
    }
}