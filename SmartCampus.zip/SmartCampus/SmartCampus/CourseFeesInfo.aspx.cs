﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;

namespace SmartCampus
{
    public partial class CourseFeesInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetClgDetailsById();
            }
        }

        private void GetClgDetailsById()
        {
            DataTable dt = new DataTable();
            int clgid = 0;

            if (Request.QueryString["ClgId"] != null)
            {
                clgid = Convert.ToInt32(Request.QueryString["ClgId"]);
            }

            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.ClgDetails WHERE ClgId=" + clgid, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    imgClgPhtot.ImageUrl = (string)dt.Rows[0]["Photo"];
                    lblClgName.Text = (string)dt.Rows[0]["Name"];
                    lblStateCity.Text = " " + (string)dt.Rows[0]["City"] + ", " + (string)dt.Rows[0]["State"];
                    lblESTD.Text = "ESTD " + (string)dt.Rows[0]["ESTDYear"];
                    //lblUniv.Text = (string)dt.Rows[0]["UniversityType"];
                    lblType.Text = (string)dt.Rows[0]["Type"];
                }
            }

            BindCourseDetails(clgid);
            BindSubStreamsFees(clgid);
        }

        private void BindCourseDetails(int clgid)
        {
            DataTable dt = new DataTable();
            int subStreamId = Convert.ToInt32(Request.QueryString["SubstreamId"]);
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * From dbo.vw_ClgSubStream WHERE Clg_Id=" + clgid + " AND SStream_Id=" + subStreamId, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    lblStream.Text = (string)dt.Rows[0]["Expr1"];
                    lblTotalFees.Text = Convert.ToString(dt.Rows[0]["TotalFees"]);
                }
            }
        }

        private void BindSubStreamsFees(int clgid)
        {
            DataTable dt = new DataTable();
            int subStreamId = Convert.ToInt32(Request.QueryString["SubstreamId"]);
            string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT FirstYearTFees, FirstYearOFees, SecondYearTFees, SecondYearOFees, ThirdYearTFees, ThirdYearOFees, FourthYearTFees, FourthYearOFees, FifthYearTFees, FifthYearOFees, SixthYearTFees, SixthYearOFees, SeventhYearTFees, SeventhYearOFees From dbo.vw_ClgSubStream WHERE Clg_Id=" + clgid + " AND SStream_Id=" + subStreamId, con))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    StringBuilder html = new StringBuilder();
                    if (dt.Rows.Count > 0)
                    {
                        int yearCounter = 0;
                        for (int i = 0; i < dt.Columns.Count; i = i + 2)
                        {
                            if (dt.Rows[0][i] != DBNull.Value || dt.Rows[0][i + 1] != DBNull.Value)
                            {
                                yearCounter += 1;
                            }
                        }


                        html.Append("<table class=\"table table-bordered table-hover\">");
                        html.Append("<thead><tr>");

                        html.Append("<th>");
                        html.Append("YEAR");
                        html.Append("</th>");

                        for (int i = 1; i <= yearCounter; i++)
                        {
                            html.Append("<th>");
                            html.Append(i);
                            html.Append("</th>");
                        }

                        html.Append("</tr></thead>");
                        html.Append("<tbody>");

                        foreach (DataRow row in dt.Rows)
                        {
                            html.Append("<tr>");
                            html.Append("<td>");
                            html.Append("TUITION FEE");
                            html.Append("</td>");

                            for (int i = 0; i < dt.Columns.Count; i = i + 2)
                            {
                                if (dt.Rows[0][i] != DBNull.Value || dt.Rows[0][i + 1] != DBNull.Value)
                                {
                                    html.Append("<td>");
                                    html.Append(row[i]);
                                    html.Append("</td>");
                                }
                            }
                        }

                        foreach (DataRow row in dt.Rows)
                        {
                            html.Append("<tr>");
                            html.Append("<td>");
                            html.Append("OTHER FEE");
                            html.Append("</td>");

                            for (int i = 0; i < dt.Columns.Count; i = i + 2)
                            {
                               
                                if (dt.Rows[0][i] != DBNull.Value || dt.Rows[0][i + 1] != DBNull.Value)
                                {
                                    html.Append("<td>");
                                    html.Append(row[i + 1]); html.Append("</td>");
                                }
                                
                            }
                        }

                        html.Append("</tbody>");
                        html.Append("</table>");
                    }

                    SubStreamPlaceHolder.Controls.Add(new Literal { Text = html.ToString() });
                }
            }
        }
    }
}